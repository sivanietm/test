# Use Lightning Component into VF page - Lightning OUT 



![VF page](https://github.com/amitastreait/lightningcomponent-into-vfpage/blob/master/VFpage-lightningout.png)

# Setp1 : - 
    Create Lightning Component

# Setp 2: - 
    Crete Lightning Application and include the component into the App

# Step 3: -
    Create a VF page and include lightning Component

# Step 4: - 
    Run VF page see the output there
